import React from 'react';
import {Link} from 'react-router-dom';
class itemList extends React.Component

{
    constructor(props) {
    super(props);
    this.state = {
      //userName: sessionStorage.getItem("userName"),
      element: [],
    };
    // this.onClickHandler = this.onClickHandler.bind(this);
  }

  componentDidMount() {
    fetch(`http://localhost:8080/api/items/findItemNameByRestaurant/${this.props.match.params.id}`)
        .then(response=>response.json())
        .then((res)=>{
            console.log(res)
            this.setState({element:res});
        });
  }

  // onClickHandler() {
  //   window.location.href = "http://localhost:3000/addItem";
  // }
  render() {
    return (
       <React.Fragment>
           <div>
           <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">ITEM ID</th>
                    <th scope="col">ITEM Name</th>
                    <th scope="col">COST</th> 
                    <th scope="col">Category</th>
                    <th scope="col">Cart</th>
                </tr>
            </thead>
                <tbody>

                
               
               {
                   this.state.element.map((i)=>(
                       <tr key={i.itemId}>
                           <td>{i.itemId}</td>
                           <td>{i.itemName}</td>
                           <td>{i.cost}</td>
                           <td>{i.category.name}</td>
                           <td>
                           
                            <Link to={`/foodCart/${i.itemId}`}>
                                            <li className="list-group-item update">
                                                <i className="fa fa-edit pr-1">Add To Cart</i>
                                            </li>
                                        </Link>
                            
                           </td>
                       </tr>
                   )
                  
                   )}
                   </tbody>
                   </table>
           </div>
       </React.Fragment>
    );
  }
}
export default itemList;

    

