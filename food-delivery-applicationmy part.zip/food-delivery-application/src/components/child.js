import React, { Component } from 'react';
class child extends Component
{
    render(){
        return(
            <div>
                <h1>child log</h1>
            </div>
        )
    }
}
export default child;