import React from 'react';
class CustomerLogin extends React.Component
{
    render(){
        return(
            <div>
                <form action="/dashboardCustomer">
                <input type="submit" className="btn btn-primary btn-block mt-4" />
                </form>
                
            </div>
        )
    }
}
export default CustomerLogin;