import react from 'react';
import customerItem from './customerItem';
import axios from 'axios';
import itemList from './itemList';
import {Link} from 'react-router-dom';
class DashBoardCustomer extends react.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            area:"",
            element: [],
            items:[],

        }
        this.onChange=this.onChange.bind(this);
        this.onSubmit=this.onSubmit.bind(this);
    }
    onChange(event)
   {

       this.setState(
           {
               [event.target.name]: event.target.value
          }            
      );

  }
  onSubmit(event){
    event.preventDefault();
    fetch(`http://localhost:8080/api/restaurants/findRestaurantByLocation/${this.state.area}`)
    .then(response=>response.json())
    .then((res) => {
      this.setState({ element: res });
    });
    this.state.element.map((restaurant)=>
    {
        fetch(`http://localhost:8080/api/items/findItemNameByRestaurant/${restaurant.id}`)
        .then(response=>response.json())
        .then((res)=>{
            this.setState({items:res});
        });
    });
    console.log(this.state.items);
    
     
     // axios.post("http://localhost:8080/api/restaurants/add",newRestaurant)
     //     .then(response=>{
     //         if(response.data!=null){
     //             alert("saved")
     //         }
     //     }) 
     //this.props.createRestaurant(newRestaurant,this.props.history);

    //console.log(newRestaurant);
    //this.componentDidMount(newRestaurant);



// componentDidMount() {
//     fetch(`http://localhost:8080/api/restaurants/findRestaurantByLocation/${this.state.area}`)
//       .then(response=>response.json())
//       .then((res) => {
//         this.setState({ element: res });
//       });
      
      
     
      
}
    
    render(){
        return(
            <div className="project">
            <div className="container">
                <div className="row">
                    <div className="col-md-8 m-auto">
                        <h5 className="display-4 text-center"></h5>
                        <hr />
                        <form onSubmit={this.onSubmit}>
                        <div class="input-group rounded">
                        <input type="search" 
                        class="form-control rounded" 
                        placeholder="Search" 
                        aria-label="Search"
                        aria-describedby="search-addon" 
                        name="area"
                        value={this.state.area}
                        onInput={this.onChange}/>
                        <span class="input-group-text border-0" id="search-addon">
                        <i class="fas fa-search"></i>
                        </span>
                        </div>
                        <input type="submit" className="btn btn-primary btn-block mt-4" />
                           
                          
                        </form>&nbsp;
                        <table class="table">
                        <thead class="thead-dark">
                        <tr>
                        <th scope="col">RestaurantId</th>
                        <th scope="col">RestaurantName</th>
                        <th scope="col">ManagerName</th> 
                        <th scope="col">ContactNumber</th>
                        <th scope="col">Search Items</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.element.length === 0 ? 
                            <tr align="center">
                            <td colspan="6">No Restaurants Present</td>
                            </tr>:
                            this.state.element.map((restaurant)=>
                            <tr key={restaurant.id}>
                            <th scope="row">{restaurant.id}</th>
                            <td>{restaurant.name}</td>
                            <td>{restaurant.managerName}</td>
                            <td>{restaurant.contactNumber}</td>
                            <td>
                            <Link to={`/itemList/${restaurant.id}`}>
                                            <li className="list-group-item update">
                                                <i className="fa fa-edit pr-1">View Menu</i>
                                            </li>
                                        </Link>
                            </td>

                            </tr>
          ) 


      }
    
  </tbody>
</table>
                        
                    </div>
                </div>
            </div>
            
       </div>
     
  
 
       )
    }
 }
            
         
          
export default DashBoardCustomer;