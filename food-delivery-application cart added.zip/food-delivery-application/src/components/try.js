import react from 'react';
import customerItem from './customerItem';
import axios from 'axios';
import itemList from './itemList';
import {Link} from 'react-router-dom';
class DashBoardCustomer extends react.Component
{
    constructor(){
        super();
        this.state={
            elements:{}
        }

    }
    componentDidMount(){
        const {id}=this.props.match.params;
        fetch(`http://localhost:8080/api/restaurants/findRestaurantByLocation/${id}`)
        .then(response=>response.json())
        .then((res) => {
        this.setState({ element: res });
    });
    }
}
          
export default DashBoardCustomer;