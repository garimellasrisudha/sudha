import React, { Component } from 'react';
import axios from 'axios';

class Order extends Component{
  constructor(){
      super();
      this.state ={
           orderDate :'',
           orderStatus :"placed",
           cartOfId:""
      };
      this.onChange=this.onChange.bind(this);
      this.onSubmit=this.onSubmit.bind(this);
  }
  onChange=event =>{
    this.setState({
        [event.target.name]:event.target.value
    });
}


onSubmit=event=>{
    event.preventDefault();
    const newOrder = this.state
    //{
    //     orderDate:this.state.orderDate,
    //     orderStatus:this.state.orderStatus,
    //     cartOfId:this.
    //    }
       axios.post("http://localhost:8080/ofd/api/orderdetail",newOrder).then(response =>{
            if(response.data !=null){
                
                    alert("Your Order is Placed");
                
              }
      }
     )
       console.log(newOrder);
}
componentDidMount(){
    this.setState({
        cartOfId:this.props.match.params.id
    })
}

    render(){
        return (

                <div className="container">
                    <div className="row">
                        <div className="col-md-8 m-auto">
                            <hr />
                            <form onSubmit={this.onSubmit}>
                                <div className="form-group">
                                <label>Select Date :</label>
                                    <input type="date" 
                                    name="orderDate"
                                    value={this.state.orderDate}
                                    placeholder="Order Date" 
                                    onChange={this.onChange}/>   
                                </div>
                                <div className="form-group">
                                <label>Order Status :</label>
                                    <select name="orderStatus"
                                    value={this.state.orderStatus} onChange={this.onChange}>
                                    <option value="placed">Placed</option>
                                    <option value="cancel">Cancel</option>
                                    <option value="pending">Pending</option>
                                    </select>
                                </div>
                                <input type="submit" className="btn btn-primary btn-block mt-4" />
                            </form>
                        </div>
                    </div>
                </div>
        
        )
    }
}
 
export default Order;