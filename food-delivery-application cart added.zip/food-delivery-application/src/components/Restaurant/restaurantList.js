import React, { Component } from 'react';
import axios from 'axios'; 
class restaurantList extends Component
{
    constructor(props){
        super(props);
        this.state={
            restaurants:[]
        };
    }
    componentDidMount(){
        axios.get("http://localhost:8080/api/restaurants/all")
        .then(response=>response.data)
        .then((data)=>{
            this.setState({restaurants:data});
        });
    }
    render(){
        return(
            <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">RestaurantId</th>
      <th scope="col">RestaurantName</th>
      <th scope="col">ManagerName</th> 
      <th scope="col">ContactNumber</th>
    </tr>
  </thead>
  <tbody>
      {
          this.state.restaurants.length === 0 ? 
          <tr align="center">
              <td colspan="6">Books Available</td>
            

          </tr>:
          this.state.restaurants.map((restaurant)=>
            <tr key={restaurant.id}>
                <th scope="row">{restaurant.id}</th>
                <td>{restaurant.name}</td>
                <td>{restaurant.managerName}</td>
                <td>{restaurant.contactNumber}</td>
            </tr>
          ) 

      }
    
  </tbody>
</table>


        )
    }
}
export default restaurantList;