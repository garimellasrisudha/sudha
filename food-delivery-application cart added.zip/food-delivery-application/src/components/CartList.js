import React, { Component } from 'react';
//import {Card, Table} from 'react-bootstrap';
import axios from 'axios';
import CreateButton from './CreateButton';
import {Link} from 'react-router-dom';

class CartList extends Component{

    constructor(props){
        super(props);
        this.state={
            items :[]
        };
    }
    componentDidMount(){
    axios.get("http://localhost:8080/ofd/api/cart/all")
        .then(response =>response.data)
        .then((res) => {
         this.setState({items : res});
        });
    }

    render(){
        return(
            <div>
            {/* <Card className={"border border-dark bg-light text-white"}>
            <Card.Header>
            </Card.Header>
            <Card.Body> */}
                 <table class="table">
                <thead class="thead-dark">
                <tr>
                    
                    <th scope="col">Cart Id</th>
                    <th scope="col">Item Name</th>
                    <th scope="col">Cost</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                   
                        
                        <tbody>
                        {this.state.items.length===0 ? 
                        
                            <tr align="center">
                            <td colSpan="6">No Item Available.</td>
                          </tr>
                           :

                        this.state.items.map((item)=>(
                            <tr key={item.itemId}>
                            <td>{item.id}</td>
                            <td>{item.items.itemName}</td>
                            <td>{item.items.cost}</td>
                            <td>{item.items.quantity}</td>
                            
                            <td>
                            <Link to={`/order/${item.id}`}>
                            <button>Order Now</button>
                            </Link>
                            </td>
                            </tr>
                        ))
                        
                        }
                         
                      
                        </tbody>
                        
                </table>
                <CreateButton/>
            
        
        </div>




        )
    }
}
export default CartList;