import React, { Component } from 'react'
import axios from 'axios';



class Cart extends Component{
    constructor(props) {
        super(props);
        this.state ={
            
            errors:{},
            items: 
                {
               
                itemName:'',
                cost:'',
                quantity:'',
            },
            element:{}

        
        };
        this.onSubmit=this.onSubmit.bind(this);
        this.onChange=this.onChange.bind(this);
        this.onChangeitemName=this.onChangeitemName.bind(this);
        this.onChangecost=this.onChangecost.bind(this);
        this.onChangequantity=this.onChangequantity.bind(this);

    }
    componentWillReceiveProps(nextProps)
    {
          if(nextProps.errors)
          {
              this.setState({errors:nextProps.errors})
          }
      }
    onSubmit= event =>{
        event.preventDefault();
        const newCart=this.state.items;
        const postData = {
            items: {
                itemName: newCart.itemName,
                quantity: newCart.quantity,
                cost: newCart.cost
            }
        }
        console.log(postData)
        axios.post("http://localhost:8080/ofd/api/cart",postData).then(response =>{
            console.log(response);
            if(response.data !=null){
                alert("added");
            }
        })
    }
            componentDidMount(){
        
       
           
                fetch(`http://localhost:8080/api/items/find/${this.props.match.params.id}`)
                .then(response=>response.json())
                .then((res)=>{
                    console.log(res)
                    this.setState({items:res});
                });
        
    
        }
        
       
    
    onChange=event =>{
        this.setState({
            [event.target.name]:event.target.value
        });
    }
    
    onChangeitemName= event =>{
        console.log(event.target.value);
        this.setState((state)=>({
            items:{
            ...state.items, itemName :event.target.value
        }
    }));
    }
    onChangecost= event =>{
        console.log(event.target.value);
        this.setState((state)=>({
            items:{
            ...state.items,cost :event.target.value
        }
    }));
    }
    onChangequantity= event =>{
        console.log(event.target.value);
        this.setState((state)=>({
            items:{
            ...state.items, quantity :event.target.value
        }
    }));
    }
    render(){
       
       // const { itemId, itemName,cost, quantity,customer_id} = this.state;

        return (
            <div className="project">
            <div className="container">
                <div className="row">
                    <div className="col-md-8 m-auto">
                        <h5 className="display-4 text-center">Add item to Cart</h5>
                        <hr />
                        <form onSubmit={this.onSubmit}>
                           
                         <div className="form-group">
                                <input type="text" 
                               className="form-control form-control-lg"
                                name="itemName" 
                                value={this.state.items.itemName}
                                placeholder="Item Name"
                                onChange={this.onChangeitemName}/>
                                <p>{this.state.errors.itemName}</p>
                            </div>
                            <div className="form-group">
                                <input type="number" 
                                className="form-control form-control-lg" 
                                name="cost"
                                value={this.state.items.cost}
                                placeholder="Cost of item"
                                onChange={this.onChangecost}/>
                                <p>{this.state.errors.cost}</p>
                            </div>
                            <div className="form-group">
                            <input type="quantity" 
                            className="form-control form-control-lg" 
                            name="quantity"
                            value={this.state.items.quantity}
                            placeholder="Quantity"
                            onChange={this.onChangequantity}/>
                            <p>{this.state.errors.quantity}</p>
                            </div>
                        
                        <input type="submit"  className="btn btn-primary btn-block mt-4" />
                        </form>
                    </div>
                </div>
            </div>
       </div>
        );
    }
};


export default Cart;
 