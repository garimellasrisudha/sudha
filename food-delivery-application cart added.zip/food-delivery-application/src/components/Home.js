import React, { Component } from 'react';
import bgImg from '../images/food.jpg'

class Home extends Component{
    render(){
        return(
            <div>
                <section className="Restaurants" style={{'backgroundImage':`url(${bgImg})`}}>
                    <h1 className="display-4"></h1>
                </section>
            </div>
        )
    }
}
export default Home;
