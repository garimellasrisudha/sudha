import react,{Component} from 'react';
//import {connect} from 'react-redux';
//import {PropTypes} from 'prop-types';

import {Link} from  'react-router-dom';
import CustomerItems from './CustomerItems';
class DashboardForCustomer extends Component{
   
    render(){
        return(
            <div className="conatainer">
            <div className="row">
                <div className="col-md-12">
                    <h1 className="display-4 text-center">Customer Details</h1>
                    <br />
                    <Link to="/customerLogin" class="btn btn-lg btn-primary">
                        Add New Customer
                    </Link>
                    <br/>

                    <hr/>
                    <CustomerItems cId={this.props.match.params.id}/>
                    
                </div>
            </div>
        </div>
    );
    }
    
}
export default DashboardForCustomer;