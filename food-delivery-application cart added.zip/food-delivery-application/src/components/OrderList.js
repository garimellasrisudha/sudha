import React, { Component } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

class OrderList extends Component{

    constructor(props){
        super(props);
        this.state={
            orders :[]
        };
    }
    componentDidMount(){
    axios.get("http://localhost:8080/ofd/api/orderdetail/all")
        .then(response =>response.data)
        .then((res) => {
         this.setState({orders : res});
        });
    }

    render(){
        return(
            <div>
            
           <table class="table">
                <thead class="thead-dark">
               
                    <tr>
                          <th scope="col">Order Id</th>
                          <th scope="col">Order status</th>
                          <th scope="col">Order Date</th>
                          <th scope="col">Action</th>
                          
                        </tr>
                
                </thead>
                   
                        
                        <tbody>
                        {this.state.orders.length===0 ? 
                        
                            <tr align="center">
                            <td colSpan="6">No Item Available.</td>
                          </tr>
                           :

                        this.state.orders.map((order)=>(
                            <tr key={order.id}>
                            <td>{order.id}</td>
                            <td>{order.orderStatus}</td>
                            <td>{order.orderDate}</td>
                            <td>
                            <Link to={"order/details/bill"}></Link>
                            <button>Generate bill</button>
                            </td>
                            
                            </tr>
                        ))
                        
                        }
                         
                      
                        </tbody>
                        
                </table>
            
            
        
        </div>




        )
    }
}
export default OrderList;