import React from 'react';
import {connect} from 'react-redux';
import PropTypes from "prop-types";
import { createCustomer } from '../actions/CustomerActions';


class CustomerLogin extends React.Component
{
    constructor(){
        super();
      this.state=
      {
            errors:{},
            id:"",
            firstName:"",
             lastName:"", 
             age:"",
             gender:"",  
              mobileNumber:"", 
              email:"",
              fetchCustomer:[],
           
           address:{
               buildingName:"",
               pinCode:"",
               streetNo:"",
               area:"",
               city:"",
               stateValue:"",
               country:"",

          },
          
          

       };
       this.onChange=this.onChange.bind(this);
       this.onSubmit=this.onSubmit.bind(this);
       this.onChangePin = this.onChangePin.bind(this);
       this.onChangearea=this.onChangearea.bind(this);
       this.onChangeBuildingName=this.onChangeBuildingName.bind(this);
       this.onChangeCity=this.onChangeCity.bind(this);
       this.onChangeStateValue=this.onChangeStateValue.bind(this);
       this.onChangeStreetNo=this.onChangeStreetNo.bind(this);
       this.onChangeCountry=this.onChangeCountry.bind(this);
     
   }
  

   onChange(event)
   {

       this.setState(
           {
               [event.target.name]: event.target.value
          }            
      );

  }
  componentWillReceiveProps(nextProps)
  {
        if(nextProps.errors)
        {
            this.setState({errors:nextProps.errors})
            this.setState({fetchCustomer:nextProps.customer})
        }
    }
  
    

   onChangePin(event){

       console.log(event.target.value);
       this.setState((state)=>({
           address: {
               ...state.address,
               pinCode : event.target.value
          }
       }));
      
   }
   onChangearea(event){

       console.log(event.target.value);
       this.setState((state)=>({
           address: {
               ...state.address,
               area : event.target.value,
           }
       }));
   }
   onChangeBuildingName(event)
   {

    console.log(event.target.value);
    this.setState((state)=>(
        {
        address: 
        {
            ...state.address,
            buildingName : event.target.value,
        }
    }));
    }
    onChangeStreetNo(event){

        console.log(event.target.value);
        this.setState((state)=>({
            address: {
                ...state.address,
                streetNo : event.target.value,
            }
        }));
    }
    onChangeCity(event){

        console.log(event.target.value);
        this.setState((state)=>({
            address: {
                ...state.address,
                city : event.target.value,
            }
        }));
    }
    onChangeStateValue(event){

        console.log(event.target.value);
        this.setState((state)=>({
            address: {
                ...state.address,
                stateValue : event.target.value,
            }
        }));
    }
    onChangeCountry(event){

        console.log(event.target.value);
        this.setState((state)=>({
            address: {
                ...state.address,
                country : event.target.value,
            }
        }));
    }
   
          
  
   onSubmit(event){
       event.preventDefault();
        const newCustomer= this.state;
        // axios.post("http://localhost:8080/api/customers/add",newCustomer)
        //     .then(response=>{
        //         if(response.data!=null){
        //             alert("Saved successfully")
        //         }
        //     }) 
        this.props.createCustomer(newCustomer,this.props.history);
       console.log(newCustomer);

   }
  
   render(){
      
       return(
           <div className="project">
       <div className="container">
           <div className="row">
               <div className="col-md-8 m-auto">
                   <h5 className="display-4 text-center">Create  Customer form</h5>
                   <hr />
                   <form onSubmit={this.onSubmit} action="/dashboardCustomer">
                       <div className="form-group">
                       <label>Customer first Name:</label>
                           <input type="text" 
                           className="form-control form-control-lg " 
                           name="firstName"
                           value={this.state.firstName}
                           placeholder="Customer First Name" 
                           onChange={this.onChange}/>
                             <span style={{color: "red"}}>{this.state.errors["firstName"]}</span>

                           
                   </div>
                    <div className="form-group">
                    <label>Customer Last Name:</label>
                           <input type="text" 
                          className="form-control form-control-lg"
                           name="lastName" 
                           value={this.state.lastName}
                           placeholder="Customer Last Name"
                           onChange={this.onChange}/>
                              <span style={{color: "red"}}>{this.state.errors["lastName"]}</span>

                           
                       </div>
                      
                      <div className="form-group">
                      <label>Customer  age:</label>
                           <input type="text" 
                          className="form-control form-control-lg"
                           name="age" 
                           value={this.state.age}
                           placeholder="Customer Age"
                           onChange={this.onChange}/>
                              <span style={{color: "red"}}>{this.state.errors["age"]}</span>

                           
                       </div>
                      
                    <div className="form-group">
                    <label>Customer Gender:</label>
                           <input type="text" 
                          className="form-control form-control-lg"
                           name="gender" 
                           value={this.state.gender}
                           placeholder="Customer Gender"
                           onChange={this.onChange}/>
                              <span style={{color: "red"}}>{this.state.errors["gender"]}</span>

                           
                       </div>
                       <div className="form-group">
                       <label>Customer Mobile Number:</label>
                           <input type="text" 
                           className="form-control form-control-lg" 
                           name="mobileNumber"
                           value={this.state.mobileNumber}
                           placeholder=" Customer Contact Number"
                           onChange={this.onChange}/>
                              <span style={{color: "red"}}>{this.state.errors["mobileNumber"]}</span>

                       </div>
                      
                    <div className="form-group">
                    <label>Customer Email:</label>
                           <input type="text" 
                          className="form-control form-control-lg"
                           name="email" 
                           value={this.state.email}
                           placeholder="Customer Email"
                           onChange={this.onChange}/>
                              <span style={{color: "red"}}>{this.state.errors["email"]}</span>

                           
                       </div>
                      
                       <div className="form-group">
                       <label>Customer Pin code:</label>
                           <input type="text" 
                           className="form-control form-control-lg" 
                           name="pinCode"
                           value={this.state.pinCode}
                           placeholder="pinCode"
                           onInput={this.onChangePin}/>
                              <span style={{color: "red"}}>{this.state.errors["pinCode"]}</span>

                       </div>
                      <div className="form-group">
                      <label>Customer Area:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="area"
                      value={this.state.area}
                           placeholder="area"
                           onInput={this.onChangearea}/>
                               <span style={{color: "red"}}>{this.state.errors["area"]}</span>

                          
                       </div>
                       <div className="form-group">
                       <label>Customer Building Name:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="address.buildingName"
                      value={this.state.buildingName}
                           placeholder="buildingname"
                           onInput={this.onChangeBuildingName}/>
                           <p>{this.state.errors.buildingName}</p>
                           
                       </div>
                       <div className="form-group">
                       <label>Customer City:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="city"
                      value={this.state.city}
                           placeholder="city"
                           onInput={this.onChangeCity}/>
                           <p>{this.state.errors.city}</p>
                       </div>
                       <div className="form-group">
                       <label>Customer State:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="state"
                      value={this.state.state}
                           placeholder="state"
                           onInput={this.onChangeState}/>
                           <p>{this.state.errors.state}</p>
                       </div>
                       <div className="form-group">
                       <label>Customer Street no:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="streetNo"
                      value={this.state.streetNo}
                           placeholder="streetNo"
                           onInput={this.onChangeStreetNo}/>
                           <p>{this.state.errors.streetNo}</p>
                       </div>
                       <div className="form-group">
                       <label>Customer Country:</label>
                           <input type="text" 
                          className="form-control form-control-lg" 
                           name="country"
                      value={this.state.country}
                           placeholder="country"
                           onInput={this.onChangeCountry}/>
                           <p>{this.state.errors.country}</p>
                       </div>
                      
                      <input type="submit" className="btn btn-primary btn-block mt-4" />
                   </form>
               </div>
           </div>
       </div>
  </div>

 

      )
   }
}
function mapStateToProps(state){
    return{
        errors:state.errors,
        customer:state.customer
    };
}
CustomerLogin.propTypes ={
    createCustomer : PropTypes.func.isRequired,
    errors:PropTypes.object.isRequired,
    customer:PropTypes.object.isRequired
}




export default connect(mapStateToProps,{createCustomer})(CustomerLogin);