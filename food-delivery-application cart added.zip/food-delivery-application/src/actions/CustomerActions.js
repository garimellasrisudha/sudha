import axios from 'axios';
import {GET_ERRORS , GET_CUSTOMERS} from './types';
export const createCustomer=(project, history)=>async dispatch=>{
    try{
    const res=await axios.post("http://localhost:8080//api/customers/add", project);
    history.push(`/dashboardForCustomer/${res.data.id}`);
    dispatch({
        type:GET_CUSTOMERS,
        payload:res.data
    })

    }catch(err){
        dispatch({
            type:GET_ERRORS,
            payload:err.response.data
        });
    }
}

