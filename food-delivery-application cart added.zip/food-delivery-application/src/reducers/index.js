import {combineReducers} from 'redux';
import RestaurantReducer from './RestaurantReducer';
import errorReducer from './errorReducer';

export default combineReducers({
    errors:errorReducer,
    restaurants:RestaurantReducer,
    customer:RestaurantReducer
});