import {GET_RESTAURANTS,GET_RESTAURANT} from '../actions/types';

const initialState={
    restaurants:[],
    restaurant:{}
};
export default function(state=initialState,action){
    switch(action.type){
        case GET_RESTAURANTS:
            return{
                ...state,
                restaurants:action.payload
            }
            case GET_RESTAURANT:
                return{
                    ...state,
                    restaurant:action.payload
                }
            
            
         
        default:
            return state;
    }
}
