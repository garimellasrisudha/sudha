import react from 'react';
//import axios from 'axios';
import {connect} from 'react-redux';
import PropTypes from "prop-types";
import {createItem} from '../../actions/ItemAction';
class addItem extends react.Component
{ 
    constructor(){
    super();
  this.state=
  {
        errors:{},
       restaurantId:"",
       itemName:"",
       quantity:"",
       cost:"",
       category:{
           name:""
       }

       
    //    address:{
    //        buildingName:"",
    //        pinCode:"",
    //        streetNo:"",
    //        area:"",
    //        city:"",
    //        stateValue:"",
    //        country:"",

    //   },
      
      

   };
   this.onChange=this.onChange.bind(this);
   this.onSubmit=this.onSubmit.bind(this);
   this.onChangeName = this.onChangeName.bind(this);
    this.onChangeNumber=this.onChangeNumber.bind(this);
    this.onChangeFloat=this.onChangeFloat.bind(this);
//    this.onChangeBuildingName=this.onChangeBuildingName.bind(this);
//    this.onChangeCity=this.onChangeCity.bind(this);
//    this.onChangeStateValue=this.onChangeStateValue.bind(this);
//    this.onChangeStreetNo=this.onChangeStreetNo.bind(this);
//    this.onChangeCountry=this.onChangeCountry.bind(this);
 
}
onChange(event)
{

   this.setState(
       {
           [event.target.name]: event.target.value
      }            
  );

}
onChangeNumber(e)
{
    this.setState({
        [e.target.name]:e.target.type==='number'?parseInt(e.target.value):e.target.value
    });
}

onChangeFloat(e)
{
    this.setState({
        [e.target.name]:e.target.name==='cost'?parseFloat(e.target.value):e.target.value
    });
}
 componentWillReceiveProps(nextProps)
 {
    if(nextProps.errors)
     {
         this.setState({errors:nextProps.errors})
     }
 }



 onChangeName(event)
 {

    console.log(event.target.value);
    this.setState((state)=>({
        category: {
            ...state.category,
            name : event.target.value
       }
    }));
}
  
// }
// onChangearea(event){

//    console.log(event.target.value);
//    this.setState((state)=>({
//        address: {
//            ...state.address,
//            area : event.target.value,
//        }
//    }));
// }
// onChangeBuildingName(event)
// {

// console.log(event.target.value);
// this.setState((state)=>(
//     {
//     address: 
//     {
//         ...state.address,
//         buildingName : event.target.value,
//     }
// }));
// }
// onChangeStreetNo(event){

//     console.log(event.target.value);
//     this.setState((state)=>({
//         address: {
//             ...state.address,
//             streetNo : event.target.value,
//         }
//     }));
// }
// onChangeCity(event){

//     console.log(event.target.value);
//     this.setState((state)=>({
//         address: {
//             ...state.address,
//             city : event.target.value,
//         }
//     }));
// }
// onChangeStateValue(event){

//     console.log(event.target.value);
//     this.setState((state)=>({
//         address: {
//             ...state.address,
//             stateValue : event.target.value,
//         }
//     }));
// }
// onChangeCountry(event){

//     console.log(event.target.value);
//     this.setState((state)=>({
//         address: {
//             ...state.address,
//             country : event.target.value,
//         }
//     }));
// }



  
      

onSubmit(event){
   event.preventDefault();
    const newItem= this.state;
    //  axios.post("http://localhost:8080/api/items/add",newItem)
    //      .then(response=>{
    //          if(response.data!=null){
    //              alert("saved")
    //          }
    //      }) 
    this.props.createItem(newItem,this.props.history);
    console.log(newItem);

}
render(){
  
   return(
       <div className="project">
   <div className="container">
       <div className="row">
           <div className="col-md-8 m-auto">
               <h5 className="display-4 text-center">Create / Edit Restaurant form</h5>
               <hr />
               <form onSubmit={this.onSubmit}>
                   <div className="form-group">
                       <input type="text" 
                       className="form-control form-control-lg " 
                       name="itemName"
                       value={this.state.itemName}
                       placeholder="Item Name" 
                       onChange={this.onChange}/>
                       <p>{this.state.errors.itemName}</p>
                       
                       
               </div>
                <div className="form-group">
                       <input type="number" 
                      className="form-control form-control-lg"
                       name="quantity" 
                       value={this.state.quantity}
                       placeholder="quantity"
                       onChange={this.onChangeNumber}/>
                       
                       
                       
                   </div>
                   <div className="form-group">
                       <input type="text" 
                       className="form-control form-control-lg" 
                       name="cost"
                       value={this.state.cost}
                       placeholder="cost"
                       onChange={this.onChangeFloat}/>
                       
                       
                   </div>
                   <div className="form-group">
                       <input type="text" 
                       className="form-control form-control-lg" 
                       name="name"
                       value={this.state.category.name}
                       placeholder="category"
                       onInput={this.onChangeName}/>
                       
                   </div>
                   <div className="form-group">
                       <input type="number" 
                       className="form-control form-control-lg" 
                       name="restaurantId"
                       value={this.state.restaurantId}
                       placeholder="restaurantId"
                       onInput={this.onChangeNumber}/>
                       
                   </div>
                  
                   {/* <div className="form-group">
                       <input type="text" 
                       className="form-control form-control-lg" 
                       name="pinCode"
                       value={this.state.address.pinCode}
                       placeholder="pinCode"
                       onInput={this.onChangePin}/>
                       <p>{this.state.errors.pinCode}</p>
                   </div>
                  <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="area"
                  value={this.state.address.area}
                       placeholder="area"
                       onInput={this.onChangearea}/>
                       <p>{this.state.errors.area}</p>
                      
                   </div>
                   <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="buildingName"
                  value={this.state.address.buildingName}
                       placeholder="buildingname"
                       onInput={this.onChangeBuildingName}/>
                       <p>{this.state.errors.buildingName}</p>
                       
                   </div>
                   <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="city"
                  value={this.state.address.city}
                       placeholder="city"
                       onInput={this.onChangeCity}/>
                       <p>{this.state.errors.city}</p>
                   </div>
                   <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="address.stateValue"
                  value={this.state.address.stateValue}
                       placeholder="stateValue"
                       onInput={this.onChangeStateValue}/>
                       <p>{this.state.errors.stateValue}</p>
                   </div>
                   <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="streetNo"
                  value={this.state.address.streetNo}
                       placeholder="streetNo"
                       onInput={this.onChangeStreetNo}/>
                       <p>{this.state.errors.streetNo}</p>
                   </div>
                   <div className="form-group">
                       <input type="text" 
                      className="form-control form-control-lg" 
                       name="country"
                  value={this.state.address.country}
                       placeholder="country"
                       onInput={this.onChangeCountry}/>
                       <p>{this.state.errors.country}</p>
                   </div> */}
                  
                  <input type="submit" className="btn btn-primary btn-block mt-4" />
               </form>
           </div>
       </div>
   </div>
</div>



  )
}
}
 function mapStateToProps(state){
 return{
     errors:state.errors
 };
 }
 addItem.propTypes ={
      createItem : PropTypes.func.isRequired,
    errors:PropTypes.object.isRequired
}




export default connect(mapStateToProps,{createItem})(addItem);

