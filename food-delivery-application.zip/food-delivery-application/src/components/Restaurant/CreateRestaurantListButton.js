import React from 'react'
import {Link} from 'react-router-dom'

const CreateRestaurantListButton= () =>{
   return (
       <React.Fragment>
           <Link to="/restaurantList" className="btn btn-lg btn-info">
               Restaurant List
           </Link>
       </React.Fragment>
   ); 
}
export default CreateRestaurantListButton;