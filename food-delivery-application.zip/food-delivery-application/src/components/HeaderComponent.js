import react from 'react';
import img1 from '../images/food.jpg';
class HeaderComponent extends react.Component
{
    render(){
        return(
            <nav className="navbar navbar-expand-sm navbar-dark bg-primary">
            <div className="container" >
                <a className="navbar-brand" href="Dashboard.html">
                    Restaurant Model
                </a>
                
                {/* <img src={img1}/>  */}
                

                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                    <span className="navbar-toggler-icon" />
                </button>
    
                <div className="collapse navbar-collapse" id="mobile-nav">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <a className="nav-link" href="/dashboard">
                                Dashboard
                            </a>
                        </li>
                    </ul>
    
                    
                </div>
            </div>
        </nav>
        );
    }
}
export default HeaderComponent;