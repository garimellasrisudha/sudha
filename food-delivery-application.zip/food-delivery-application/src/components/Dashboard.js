import react from 'react';
import CreateRestaurantButton from './Restaurant/CreateRestaurantButton';
import CreateRestaurantListButton from './Restaurant/CreateRestaurantListButton';
import RestaurantComponent from './RestaurantComponent';
import {connect} from 'react-redux';
import {getRestaurants} from '../actions/RestaurantAction';
import {PropTypes} from 'prop-types';
import bgImg from '../images/food.jpg'

class Dashboard extends react.Component
{
     componentDidMount(){
         this.props.getRestaurants();
     }
    render(){
        const restaurants=this.props.restaurants.restaurants;
        return(
            <div className="Restaurants" style={{'backgroundImage': `url(${bgImg})` }}>
        <div class="container">
            
            <div className="row">
                <div className="col-md-12">
                    <h1 className="display-4 text-center text-white">Restaurants</h1>
                    <br />
                   
                    <CreateRestaurantButton/>&nbsp;&nbsp;
                     <CreateRestaurantListButton/>
                    
                    
                    <br />
                    <hr />
                     {
                        restaurants.map(restaurant=>(
                            <RestaurantComponent key={restaurant.id} restaurant={restaurant}/>
                            ))
                    } 
                    
                   
                </div>
            </div>
        </div>
    </div>

   

        );
    }
}
Dashboard.propTypes ={
    getRestaurants : PropTypes.func.isRequired,
    restaurants:PropTypes.object.isRequired
}

const mapStateToProps=state=>({
    restaurants:state.restaurants
});

export default connect(mapStateToProps,{getRestaurants})(Dashboard);