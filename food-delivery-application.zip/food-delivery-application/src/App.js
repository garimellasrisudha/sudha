import './App.css';
import Dashboard from './components/Dashboard';
import HeaderComponent from './components/HeaderComponent';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import addRestaurant from './components/Restaurant/addRestaurant';
import child from './components/child';
import {Provider} from 'react-redux';
import store from './store'; 
import addItem from './components/Restaurant/addItem';
import restaurantList from './components/Restaurant/restaurantList';
import updateRestaurant from './components/Restaurant/updateRestaurant';
import Home from './components/Home';

function App() {
  return (
    <Provider store={store}>
      <Router>
          
          <div className="App">
          <HeaderComponent/>
          </div> 
         
          <Route path="/" component={Home} exact={true}/>
          <Route path="/dashboard" component={Dashboard} exact={true}/>
          <Route path="/addRestaurant" component={addRestaurant} exact={true}/>
          <Route path="/addChild" component={child} exact={true} />
          <Route path="/addItem" component={addItem} exact={true}/>
          <Route path="/restaurantList" component={restaurantList} exact={true}/>
          <Route path="/updateRestaurant/:id" component={updateRestaurant} exact={true}/>
        </Router>
       
    </Provider>
        
   
  );
}

export default App;
