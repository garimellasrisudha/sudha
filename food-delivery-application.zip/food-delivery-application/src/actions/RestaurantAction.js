import axios from 'axios';
import {GET_ERRORS,GET_RESTAURANT, GET_RESTAURANTS,DELETE_RESTAURANT} from './types';
export const createRestaurant=(restaurant,history)=>async dispatch=>
{
    try{
        const res = await axios.post("http://localhost:8080/api/restaurants/add",restaurant);
        history.push("/dashboard");

    }
    catch(err)
    {
        dispatch({
            type:GET_ERRORS,
            payload:err.response.data
        });
    }
}
export const getRestaurants =()=> async dispatch => {
    const res = await axios.get("http://localhost:8080/api/restaurants/all");
    dispatch({
        type:GET_RESTAURANTS,
        payload:res.data
    });
}

export const getRestaurant =(id,history)=> async dispatch=>{
    const res=await axios.get(`http://localhost:8080/api/restaurants/find/${id}`);
    dispatch({
        type:GET_RESTAURANT,
        payload:res.data
    });
}
export const deleteRestaurant =id=> async dispatch=>{
    await axios.delete(`http://localhost:8080/api/restaurants/delete/${id}`);
    dispatch({
        type:DELETE_RESTAURANT,
        payload:id
    });
   
}
